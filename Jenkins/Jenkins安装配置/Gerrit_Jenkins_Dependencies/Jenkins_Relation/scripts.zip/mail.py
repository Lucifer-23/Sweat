# -*- coding: UTF-8 -*-

import smtplib  
from email.mime.text import MIMEText  

mailto_list=["pearce@qqc88.net"] 
mailcc_list=["pearce@qqc88.net","qqc.pearce@gmail.com"] 
mailbcc_list=[""] 
mail_host="smtp.gmail.com"
mail_port="465"
mail_user="qqc.pearce23@gmail.com"
mail_pass="qqc.pearce23@123"
mail_from="Jenkins<qqc.pearce23@gmail.com>"
  
def send_mail(sub,content):  
    #msg = MIMEText(content,_subtype='plain',_charset='gb2312')  
    msg = MIMEText('Build successfull!!!\n Your files are in the under server path:\n' + content) 
    msg['Subject'] = sub  
    msg['From'] = mail_from  
    msg['To'] = ";".join(mailto_list)  
    msg['Cc'] = ";".join(mailcc_list)  
    msg['Bcc'] = ";".join(mailbcc_list)  
    try:  
        server = smtplib.SMTP_SSL(mail_host, mail_port)  
        #server.connect(mail_host)  
        server.login(mail_user,mail_pass)  
        server.sendmail(mail_from, mailto_list + mailcc_list + mailbcc_list, msg.as_string())  
        server.close()  
        return True  
    except Exception, e:  
        print str(e)  
        return False  
if __name__ == '__main__':  
    if send_mail("hello","hello world！"):  
        print "OK"  
    else:  
        print "Mail Fail"
