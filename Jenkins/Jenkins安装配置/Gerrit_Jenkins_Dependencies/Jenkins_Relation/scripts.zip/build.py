import os
import time
from ftplib import FTP
import mail
import sys

APK_DIR="%s/app/build/outputs/apk/"%(os.getenv('WORKSPACE'))
BUILD_DATE = time.strftime("%Y_%m_%d_%H_%M", time.localtime(time.time()))

def Upload_Ftp_Server(name):
    ftp = ftpconnect()
    print("Panda: " + ftp.getwelcome())
    path = "/pub/App/%s/"%name
    if not os.path.exists('/srv/ftp' + path):
        ftp.mkd(path)
    path = "%s%s"%(path,BUILD_DATE[11:] + '_build_' + os.getenv('BUILD_DISPLAY_NAME')[1:])
    ftp.mkd(path)
    ftp.cwd(path)
    files = os.listdir("./products/")
    for f in files:
        fp = open("products/%s"%f, "rb")
        ftp.storbinary("STOR " + os.path.basename(f), fp, 1024)
        fp.close()
        print("Panda: Upload apk file to ftp server succeed and url is ftp://www.pearce.com" + path + '/' + f)
    ftp.quit()
    print(path)
    return path

def ftpconnect():
    ftp_server = 'www.pearce.com'
    username = 'anonymous'
    password = ''
    ftp = FTP()
    ftp.set_debuglevel(2)
    ftp.connect(ftp_server,21)
    ftp.login(username,password)
    return ftp

def copyApks(rootDir):
    print("Panda: apks direcotry is %s"%rootDir)
    for filename in os.listdir(rootDir):
        pathname = os.path.join(rootDir, filename)
        if (os.path.isdir(pathname)):
            copyApks(pathname)
        else:
            if filename.endswith(".apk"):
                os.system('cp %s products/%s'%(pathname,filename))

if __name__ == "__main__":
    is_release = True
    if len(sys.argv) > 1:
        if sys.argv[1] == 'Debug':
            is_release = False
    if os.path.exists('./products/'):
        os.system('rm -rf ./products/')
    os.mkdir('./products/')
    copyApks(APK_DIR)
    apks = os.listdir('./products/')
    if len(apks) > 0:
        os.system("md5sum ./products/*")
    flag = 'debug'
    if is_release:
        flag = 'release'
    path = Upload_Ftp_Server("%s_%s_%s"%(os.getenv('JOB_NAME'),flag,BUILD_DATE[:10]))
    content = 'ftp://192.168.75.133%s'%path
    mail.send_mail("jenkins build %s successful"%(os.getenv('JOB_NAME')), content)
