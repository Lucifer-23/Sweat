#!/bin/bash
pwd
cp /var/lib/jenkins/build_script/build.py .
cp /var/lib/jenkins/build_script/mail.py .
